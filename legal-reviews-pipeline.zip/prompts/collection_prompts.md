# Prompty pro sběr (kanál + lokalita)

> Tyto prompty jsou navržené tak, aby výsledkem byl **jednotný JSON** do `/data/inbox`.
> Důležité: sběr musí být v souladu s ToS zdrojů.

## 0) Společná pravidla
- Nikdy nevymýšlej rating/datum/text.
- Pokud něco není vidět, pole vynech.
- Výstup vždy jen validní JSON podle schématu.

## 1) Google Maps Reviews (PRAHA) – 1 běh

Zkopíruj prompt níže do ChatGPT a použij web browsing (pokud je k dispozici).

```
ROLE
Jsi “review data collector & QA”.

Cíl: nasbírat recenze pro všechny firmy (seznam níže) z Google Maps pro lokalitu PRAHA.

Postup:
- projdi firmu po firmě
- najdi odpovídající Google Maps profil (Praha / CZ)
- vytáhni 10–20 recenzí, pokud existují
- pokud neexistují, přeskoč

Vrať pouze validní JSON ve struktuře:
{
  "source": "google_maps_reviews",
  "location": "Praha",
  "collected_at": "2026-03-04",
  "reviews": [
    {
      "firm": "",
      "city": "Praha",
      "review_text": "",
      "review_date": "YYYY-MM-DD",
      "rating": 5,
      "sentiment": "positive|neutral|negative"
    }
  ]
}

Pravidla:
- rating a review_date vynech, pokud nejsou dostupné
- sentiment urči jen z textu recenze
- žádný jiný text mimo JSON

SEZNAM FIREM:
Spring Walk
HAVEL & PARTNERS
PORTOS
ROWAN LEGAL
Dentons
PRK Partners
Sokol, Novák, Trojan, Doleček a partneři
Glatzová & Co.
Kinstellar
Deloitte Legal
act Řanda Havel Legal
DLA Piper
Eversheds Sutherland
DBK PARTNERS
Chrenek, Toman, Kotrba
Taylor Wessing
Doležal & Partners
Advokátní kancelář Petráš Rezek
Aegis Law
Bříza & Trubač
DUNOVSKÁ & PARTNERS
Rödl & Partner
LEGALITÉ
Advokátní kancelář Brož, Sedlatý
ŽIŽLAVSKÝ
MT Legal
MELKUS KEJLA & PARTNERS
Urban & Hejduk
HSP & Partners
Konečná & Zacha
Wilsons
```

## 2) Firmy.cz (PRAHA) – 1 běh

Stejný prompt, jen source změň na `firmy_cz_reviews`.
