import fs from 'node:fs';
import path from 'node:path';
import { loadInbox, mergeBatches } from './merge.mjs';
import { dedupeReviews } from './dedupe.mjs';
import { enrichReviews } from './enrich.mjs';

function writeJson(fp, obj) {
  fs.mkdirSync(path.dirname(fp), { recursive: true });
  fs.writeFileSync(fp, JSON.stringify(obj, null, 2), 'utf-8');
}

const inbox = loadInbox('data/inbox');
const merged = mergeBatches(inbox);
const deduped = dedupeReviews(merged);
const enriched = await enrichReviews(deduped);

writeJson('public/data/dataset.json', deduped);
writeJson('public/data/enriched.json', enriched);

console.log(`Done:
- inbox files: ${inbox.length}
- merged reviews: ${(merged.reviews ?? []).length}
- deduped reviews: ${(deduped.reviews ?? []).length}
- enriched reviews: ${(enriched.reviews ?? []).length}
`);
