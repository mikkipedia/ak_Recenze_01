import fs from 'node:fs';
import path from 'node:path';

const inboxDir = path.resolve('data/inbox');

function die(msg) {
  console.error(msg);
  process.exit(1);
}

function isObject(x) {
  return x && typeof x === 'object' && !Array.isArray(x);
}

function validateFile(fp) {
  const raw = fs.readFileSync(fp, 'utf-8');
  let data;
  try { data = JSON.parse(raw); } catch (e) { die(`Invalid JSON: ${fp}\n${e}`); }
  const requiredTop = ['source','location','collected_at','reviews'];
  for (const k of requiredTop) {
    if (!(k in data)) die(`Missing top-level field "${k}" in ${fp}`);
  }
  if (!Array.isArray(data.reviews)) die(`"reviews" must be an array in ${fp}`);

  for (const [i, r] of data.reviews.entries()) {
    if (!isObject(r)) die(`Review #${i} is not object in ${fp}`);
    for (const k of ['firm','city','review_text','sentiment']) {
      if (!(k in r)) die(`Missing review field "${k}" at index ${i} in ${fp}`);
    }
    if (typeof r.firm !== 'string' || !r.firm.trim()) die(`Invalid firm at ${fp}[${i}]`);
    if (typeof r.city !== 'string' || !r.city.trim()) die(`Invalid city at ${fp}[${i}]`);
    if (typeof r.review_text !== 'string' || !r.review_text.trim()) die(`Invalid review_text at ${fp}[${i}]`);
    if (!['positive','neutral','negative'].includes(r.sentiment)) die(`Invalid sentiment at ${fp}[${i}]: ${r.sentiment}`);
    if ('rating' in r && (typeof r.rating !== 'number' || r.rating < 0 || r.rating > 5)) die(`Invalid rating at ${fp}[${i}]`);
    if ('review_date' in r && (typeof r.review_date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(r.review_date))) die(`Invalid review_date format at ${fp}[${i}]`);
  }
}

if (!fs.existsSync(inboxDir)) {
  console.log('No inbox directory, skipping.');
  process.exit(0);
}

const files = fs.readdirSync(inboxDir).filter(f => f.endsWith('.json'));
if (files.length === 0) {
  console.log('No inbox JSON files found.');
  process.exit(0);
}

for (const f of files) {
  validateFile(path.join(inboxDir, f));
}

console.log(`OK: validated ${files.length} inbox files.`);
