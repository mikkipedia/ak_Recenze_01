import { reviewKey } from './lib.mjs';

export function dedupeReviews(merged) {
  const seen = new Set();
  const deduped = [];
  for (const r of merged.reviews ?? []) {
    const k = reviewKey(r);
    if (seen.has(k)) continue;
    seen.add(k);
    deduped.push({ ...r, _id: k });
  }
  return { ...merged, reviews: deduped };
}
