import fs from 'node:fs';
import path from 'node:path';
import OpenAI from 'openai';
import { normText } from './lib.mjs';

const CACHE_PATH = path.resolve('data/processed/enrichment-cache.json');

function loadCache() {
  if (!fs.existsSync(CACHE_PATH)) return {};
  try { return JSON.parse(fs.readFileSync(CACHE_PATH, 'utf-8')); } catch { return {}; }
}

function saveCache(cache) {
  fs.mkdirSync(path.dirname(CACHE_PATH), { recursive: true });
  fs.writeFileSync(CACHE_PATH, JSON.stringify(cache, null, 2), 'utf-8');
}

function makePrompt(review) {
  const firm = review.firm ?? '';
  const city = review.city ?? '';
  const text = normText(review.review_text ?? '');
  const rating = review.rating != null ? String(review.rating) : '';
  return `Analyzuj tuto recenzi právních služeb (CZ). Vrať POUZE validní JSON.

Firma: ${firm}
Město: ${city}
Rating: ${rating}
Text: ${text}

Požadovaný výstup (JSON):
{
  "sentiment": "positive|neutral|negative",
  "factors": [
    {
      "label": "stručný faktor (např. 'rychlost', 'komunikace', 'cena', 'odbornost', 'empatie', 'transparentnost', 'výsledek', 'dostupnost')",
      "polarity": "positive|negative",
      "evidence": "krátká citace/para z textu (max 15 slov)"
    }
  ]
}

Pravidla:
- sentiment vyber jen z: positive, neutral, negative
- factors max 6 položek
- evidence jen z textu recenze (nepřidávej fakta mimo text)
`;
}

export async function enrichReviews(dataset, { model = process.env.OPENAI_MODEL || 'gpt-4.1-mini', maxPerRun = 120 } = {}) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    // No key → return dataset as-is
    return { ...dataset, reviews: (dataset.reviews ?? []).map(r => ({ ...r, factors: r.factors ?? [] })) };
  }

  const client = new OpenAI({ apiKey });
  const cache = loadCache();

  let processed = 0;
  const outReviews = [];

  for (const r of dataset.reviews ?? []) {
    const id = r._id;
    if (id && cache[id]) {
      outReviews.push({ ...r, ...cache[id] });
      continue;
    }
    if (processed >= maxPerRun) {
      outReviews.push({ ...r });
      continue;
    }

    const prompt = makePrompt(r);

    let parsed = null;
    try {
      const resp = await client.chat.completions.create({
        model,
        messages: [
          { role: 'system', content: 'Jsi přesný analytik sentimentu. Vrať pouze JSON.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0
      });

      const text = resp.choices?.[0]?.message?.content ?? '';
      parsed = JSON.parse(text);
    } catch (e) {
      // keep review without enrichment
      outReviews.push({ ...r });
      processed += 1;
      continue;
    }

    // minimal validation / normalization
    const sentiment = ['positive','neutral','negative'].includes(parsed.sentiment) ? parsed.sentiment : (r.sentiment ?? null);
    const factors = Array.isArray(parsed.factors) ? parsed.factors
      .filter(f => f && typeof f.label === 'string' && typeof f.polarity === 'string')
      .slice(0, 6)
      .map(f => ({
        label: normText(f.label).slice(0, 60),
        polarity: (f.polarity === 'positive' ? 'positive' : 'negative'),
        evidence: typeof f.evidence === 'string' ? normText(f.evidence).slice(0, 120) : ''
      }))
      : [];

    const enrichment = { sentiment: sentiment ?? r.sentiment, factors };

    outReviews.push({ ...r, ...enrichment });
    if (id) cache[id] = enrichment;
    processed += 1;
  }

  saveCache(cache);
  return { ...dataset, enriched_at: new Date().toISOString(), reviews: outReviews };
}
