import fs from 'node:fs';
import path from 'node:path';

export function loadInbox(inboxDir = 'data/inbox') {
  const dir = path.resolve(inboxDir);
  if (!fs.existsSync(dir)) return [];
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  const batches = [];
  for (const f of files) {
    const fp = path.join(dir, f);
    const raw = fs.readFileSync(fp, 'utf-8');
    const data = JSON.parse(raw);
    batches.push({ file: f, data });
  }
  return batches;
}

export function mergeBatches(batches) {
  const out = {
    source: 'mixed',
    location: 'mixed',
    collected_at: null,
    generated_at: new Date().toISOString().slice(0,10),
    reviews: []
  };
  for (const b of batches) {
    const { data, file } = b;
    const src = data.source;
    const loc = data.location;
    const collected = data.collected_at;
    for (const r of data.reviews ?? []) {
      out.reviews.push({
        ...r,
        source: r.source ?? src,
        location: r.location ?? loc,
        collected_at: r.collected_at ?? collected,
        _inbox_file: file
      });
    }
  }
  return out;
}
