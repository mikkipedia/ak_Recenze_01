import crypto from 'node:crypto';

export function stableHash(obj) {
  const s = JSON.stringify(obj, Object.keys(obj).sort());
  return crypto.createHash('sha256').update(s, 'utf8').digest('hex');
}

export function normText(s) {
  return (s ?? '').toString().trim().replace(/\s+/g, ' ');
}

export function reviewKey(r) {
  // conservative key: firm + city + normalized text + date + rating + source
  const keyObj = {
    firm: normText(r.firm).toLowerCase(),
    city: normText(r.city).toLowerCase(),
    review_text: normText(r.review_text).toLowerCase(),
    review_date: r.review_date ?? null,
    rating: r.rating ?? null,
    source: r.source ?? null
  };
  return stableHash(keyObj);
}
