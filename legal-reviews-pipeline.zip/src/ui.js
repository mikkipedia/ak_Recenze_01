function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else node.setAttribute(k, v);
  }
  for (const child of children) {
    if (child == null) continue;
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

function escapeHtml(s) {
  return (s ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

async function fetchJson(path) {
  const res = await fetch(path, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  return await res.json();
}

function uniq(arr) {
  return Array.from(new Set(arr)).sort((a,b) => a.localeCompare(b, 'cs'));
}

function groupCount(items, keyFn) {
  const m = new Map();
  for (const it of items) {
    const k = keyFn(it) ?? '';
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return Array.from(m.entries()).sort((a,b) => b[1]-a[1]);
}

function topFactors(items, polarity = 'positive', limit = 12) {
  const m = new Map();
  for (const it of items) {
    const factors = (it.factors ?? []).filter(f => f && f.polarity === polarity && f.label);
    for (const f of factors) {
      const label = f.label.trim();
      m.set(label, (m.get(label) ?? 0) + 1);
    }
  }
  return Array.from(m.entries()).sort((a,b) => b[1]-a[1]).slice(0, limit);
}

export async function renderApp(root) {
  root.innerHTML = '';
  const header = el('div', { class: 'header' }, [
    el('h1', {}, ['Legal Reviews Dashboard (CZ)']),
    el('div', { class: 'sub' }, ['Dataset: ', el('span', { id: 'meta' }, ['loading…'])])
  ]);

  const filters = el('div', { class: 'filters' }, []);
  const content = el('div', { class: 'content' }, []);
  const errorBox = el('pre', { class: 'error', style: 'display:none;' }, []);

  root.appendChild(styleTag());
  root.appendChild(header);
  root.appendChild(filters);
  root.appendChild(content);
  root.appendChild(errorBox);

  let data;
  try {
    data = await fetchJson('/data/enriched.json');
  } catch (e) {
    try {
      data = await fetchJson('/data/dataset.json');
    } catch (e2) {
      errorBox.style.display = 'block';
      errorBox.textContent = String(e2);
      return;
    }
  }

  const reviews = data.reviews ?? [];
  document.getElementById('meta').textContent = `${reviews.length} recenzí • ${data.source ?? 'mixed'} • ${data.generated_at ?? data.collected_at ?? ''}`;

  const firms = uniq(reviews.map(r => r.firm).filter(Boolean));
  const cities = uniq(reviews.map(r => r.city).filter(Boolean));
  const sources = uniq(reviews.map(r => r.source ?? data.source).filter(Boolean));
  const sentiments = uniq(reviews.map(r => r.sentiment).filter(Boolean));

  const state = {
    firm: '',
    city: '',
    source: '',
    sentiment: '',
    q: ''
  };

  function mkSelect(label, key, options) {
    const select = el('select', { onchange: (e) => { state[key] = e.target.value; render(); } }, [
      el('option', { value: '' }, ['(vše)']),
      ...options.map(o => el('option', { value: o }, [o]))
    ]);
    return el('label', { class: 'filter' }, [
      el('div', { class: 'filter-label' }, [label]),
      select
    ]);
  }

  const qInput = el('input', {
    type: 'search',
    placeholder: 'Hledat v textech…',
    oninput: (e) => { state.q = e.target.value; render(); }
  });

  filters.appendChild(mkSelect('Firma', 'firm', firms));
  filters.appendChild(mkSelect('Město', 'city', cities));
  filters.appendChild(mkSelect('Zdroj', 'source', sources));
  filters.appendChild(mkSelect('Sentiment', 'sentiment', sentiments));
  filters.appendChild(el('label', { class: 'filter' }, [
    el('div', { class: 'filter-label' }, ['Text']),
    qInput
  ]));

  function applyFilters(items) {
    const q = state.q.trim().toLowerCase();
    return items.filter(r => {
      if (state.firm && r.firm !== state.firm) return false;
      if (state.city && r.city !== state.city) return false;
      const src = r.source ?? data.source;
      if (state.source && src !== state.source) return false;
      if (state.sentiment && r.sentiment !== state.sentiment) return false;
      if (q && !(r.review_text ?? '').toLowerCase().includes(q)) return false;
      return true;
    });
  }

  function render() {
    content.innerHTML = '';
    const filtered = applyFilters(reviews);

    const stats = el('div', { class: 'grid' }, [
      card('Recenzí', String(filtered.length)),
      card('Pozitivní', String(filtered.filter(r => r.sentiment === 'positive').length)),
      card('Neutrální', String(filtered.filter(r => r.sentiment === 'neutral').length)),
      card('Negativní', String(filtered.filter(r => r.sentiment === 'negative').length)),
    ]);

    const byFirm = groupCount(filtered, r => r.firm).slice(0, 12);
    const byCity = groupCount(filtered, r => r.city).slice(0, 12);

    const topPos = topFactors(filtered, 'positive', 10);
    const topNeg = topFactors(filtered, 'negative', 10);

    const insights = el('div', { class: 'grid2' }, [
      listCard('Top firmy (počet recenzí)', byFirm),
      listCard('Top města (počet recenzí)', byCity),
      listCard('Top pozitivní faktory', topPos),
      listCard('Top negativní faktory', topNeg),
    ]);

    const table = el('div', { class: 'table' }, [
      el('div', { class: 'table-head' }, [
        el('div', {}, ['Firma']),
        el('div', {}, ['Město']),
        el('div', {}, ['Zdroj']),
        el('div', {}, ['Sentiment']),
        el('div', {}, ['Datum']),
        el('div', {}, ['Rating']),
        el('div', {}, ['Text'])
      ]),
      ...filtered.slice(0, 200).map(r => el('div', { class: 'table-row' }, [
        el('div', {}, [r.firm ?? '']),
        el('div', {}, [r.city ?? '']),
        el('div', {}, [r.source ?? data.source ?? '']),
        el('div', { class: `pill ${r.sentiment ?? ''}` }, [r.sentiment ?? '']),
        el('div', {}, [r.review_date ?? '']),
        el('div', {}, [r.rating != null ? String(r.rating) : '']),
        el('div', { class: 'text' }, [r.review_text ?? ''])
      ]))
    ]);

    content.appendChild(stats);
    content.appendChild(insights);
    content.appendChild(el('div', { class: 'note' }, [
      `Zobrazeno max 200 recenzí (pro výkon). Filtrovaný výsledek: ${filtered.length}.`
    ]));
    content.appendChild(table);
  }

  render();
}

function card(title, value) {
  return el('div', { class: 'card' }, [
    el('div', { class: 'card-title' }, [title]),
    el('div', { class: 'card-value' }, [value]),
  ]);
}

function listCard(title, pairs) {
  return el('div', { class: 'card' }, [
    el('div', { class: 'card-title' }, [title]),
    el('div', { class: 'list' }, pairs.length ? pairs.map(([k,v]) =>
      el('div', { class: 'list-row' }, [
        el('div', { class: 'k' }, [k]),
        el('div', { class: 'v' }, [String(v)])
      ])
    ) : [el('div', { class: 'muted' }, ['(žádná data)'])])
  ]);
}

function styleTag() {
  const css = `
    :root { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; }
    body { margin: 0; background: #0b0c10; color: #e8e8ea; }
    .header { padding: 20px 18px 6px; border-bottom: 1px solid rgba(255,255,255,0.08); }
    h1 { margin: 0 0 6px; font-size: 18px; font-weight: 650; }
    .sub { font-size: 12px; opacity: 0.8; }
    .filters { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; padding: 12px 18px; border-bottom: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.02); }
    .filter-label { font-size: 11px; opacity: 0.75; margin-bottom: 4px; }
    select, input { width: 100%; padding: 9px 10px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.03); color: #e8e8ea; outline: none; }
    .content { padding: 14px 18px 28px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin-bottom: 10px; }
    .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; margin: 10px 0 14px; }
    .card { border-radius: 16px; padding: 12px 12px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); }
    .card-title { font-size: 12px; opacity: 0.8; margin-bottom: 6px; }
    .card-value { font-size: 22px; font-weight: 700; letter-spacing: 0.2px; }
    .list { display: grid; gap: 6px; margin-top: 6px; }
    .list-row { display: grid; grid-template-columns: 1fr auto; gap: 10px; padding: 6px 8px; border-radius: 12px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); }
    .muted { opacity: 0.7; font-size: 12px; }
    .table { border-radius: 16px; overflow: hidden; border: 1px solid rgba(255,255,255,0.08); }
    .table-head, .table-row { display: grid; grid-template-columns: 180px 110px 140px 110px 110px 80px 1fr; gap: 10px; padding: 10px 12px; }
    .table-head { background: rgba(255,255,255,0.06); font-size: 12px; opacity: 0.85; }
    .table-row { border-top: 1px solid rgba(255,255,255,0.06); font-size: 13px; }
    .table-row .text { opacity: 0.95; }
    .pill { display: inline-flex; align-items: center; justify-content: center; padding: 4px 10px; border-radius: 999px; font-size: 12px; border: 1px solid rgba(255,255,255,0.10); background: rgba(255,255,255,0.03); width: fit-content; }
    .pill.positive { border-color: rgba(0,255,128,0.25); }
    .pill.neutral { border-color: rgba(255,255,255,0.22); }
    .pill.negative { border-color: rgba(255,64,64,0.28); }
    .note { font-size: 12px; opacity: 0.75; margin: 10px 2px 10px; }
    .error { padding: 12px 18px; color: #ffb4b4; }
    @media (max-width: 980px) {
      .table-head, .table-row { grid-template-columns: 140px 90px 120px 100px 90px 70px 1fr; }
    }
  `;
  const tag = document.createElement('style');
  tag.textContent = css;
  return tag;
}
