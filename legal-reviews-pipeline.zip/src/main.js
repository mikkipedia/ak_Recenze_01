import { renderApp } from './ui.js';
renderApp(document.getElementById('app'));
